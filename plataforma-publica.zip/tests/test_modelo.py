import pandas as pd
from descarbonizacion.plantilla import crear_plantilla
from descarbonizacion.ejercicios import ejecutar_operativo
from descarbonizacion.carga import cargar_activo

from descarbonizacion.preparacion import preparar_serie
from descarbonizacion.analisis import analizar_impacto


def test_preparar_serie_imputa_mes_faltante_con_media_del_mismo_mes():
    source = pd.DataFrame({
        "fecha": pd.to_datetime(["2023-01-01", "2023-03-01", "2024-02-01"]),
        "consumo_kwh": [100.0, 120.0, 80.0],
    })
    result = preparar_serie(source)
    feb_2023 = result.loc[result.fecha.eq(pd.Timestamp("2023-02-01"))].iloc[0]
    assert feb_2023.consumo_kwh_analisis == 80.0
    assert feb_2023.metodo_imputacion == "media_mismo_mes"


def test_analizar_impacto_calcula_co2e_evitado():
    fechas = pd.date_range("2022-01-01", periods=30, freq="MS")
    consumos = [1000 + index * 3 if index < 18 else 780 + index * 3 for index in range(30)]
    detalle, resumen = analizar_impacto(
        preparar_serie(pd.DataFrame({"fecha": fechas, "consumo_kwh": consumos})),
        pd.Timestamp("2023-07-01"),
        0.2,
    )
    assert resumen["elegible_inferencia"] is True
    assert detalle.loc[detalle.periodo.eq("POST"), "tco2e_evitadas"].sum() > 0


def test_crear_plantilla_contiene_hojas_controladas(tmp_path):
    path = crear_plantilla(tmp_path / "activo.xlsx")
    hojas = set(pd.ExcelFile(path).sheet_names)
    assert {"03_Consumos", "05_CAPEX_y_medidas", "07_Calidad_y_auditoría"}.issubset(hojas)


def test_ejecutar_operativo_sin_intervencion_entrega_tendencia():
    consumos = pd.DataFrame({
        "fecha": pd.date_range("2024-01-01", periods=12, freq="MS"),
        "recurso": ["Electricidad"] * 12,
        "medidor_cuenta": ["M-1"] * 12,
        "valor": [1000 + indice * 10 for indice in range(12)],
        "unidad": ["kWh"] * 12,
        "ruta_evidencia": ["factura.pdf"] * 12,
        "estado_calidad": ["Verificado"] * 12,
    })
    factores = pd.DataFrame({"recurso": ["Electricidad"], "factor_kgco2e_unidad": [0.2], "estado_calidad": ["Verificado"]})
    detalle, resumen, excepciones = ejecutar_operativo({"fecha_intervencion": None}, consumos, factores)
    assert resumen["modo"] == "operativo_sin_intervencion"
    assert resumen["consumo_kwh_total"] == 12660
    assert resumen["tco2e_total"] == 2.532
    assert excepciones == []
    assert len(detalle) == 12


def test_cargar_activo_legacy_convierte_consumo_mensual(tmp_path):
    origen = tmp_path / "legacy.xlsx"
    with pd.ExcelWriter(origen) as writer:
        pd.DataFrame({"Campo": ["nombre_activo", "factor_emision_kgco2e_kwh"], "Valor": ["Bodega", 0.2]}).to_excel(writer, sheet_name="Activo", index=False)
        pd.DataFrame({"fecha": [pd.Timestamp("2024-01-01")], "consumo_kwh": [100.0]}).to_excel(writer, sheet_name="Consumo_mensual", index=False)
    meta, consumos, factores, capex, riesgos = cargar_activo(origen)
    assert meta["nombre_activo"] == "Bodega"
    assert consumos.loc[0, "recurso"] == "Electricidad"
    assert factores.loc[0, "factor_kgco2e_unidad"] == 0.2
    assert capex.empty and riesgos.empty


def test_cargar_activo_lee_plantilla_controlada(tmp_path):
    origen = crear_plantilla(tmp_path / "controlada.xlsx")
    from openpyxl import load_workbook
    libro = load_workbook(origen)
    libro["02_Activo_y_límites"]["B5"] = "ACT-1"
    libro["02_Activo_y_límites"]["B6"] = "Activo controlado"
    libro["03_Consumos"]["A5"] = pd.Timestamp("2024-01-01")
    libro["03_Consumos"]["B5"] = "Electricidad"
    libro["03_Consumos"]["C5"] = "M-1"
    libro["03_Consumos"]["D5"] = 100
    libro["03_Consumos"]["E5"] = "kWh"
    libro["03_Consumos"]["K5"] = "Verificado"
    libro.save(origen)
    meta, consumos, _, _, _ = cargar_activo(origen)
    assert meta["id_activo"] == "ACT-1"
    assert consumos.loc[0, "valor"] == 100
