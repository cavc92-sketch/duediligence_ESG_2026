import subprocess
import sys
from pathlib import Path


def test_main_plantilla_crea_archivo(tmp_path: Path):
    destino = tmp_path / "activo.xlsx"
    result = subprocess.run(
        [sys.executable, "main.py", "plantilla", "--output", str(destino)],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert destino.is_file()


def test_py_main_usa_entorno_virtual_del_proyecto(tmp_path: Path):
    destino = tmp_path / "activo_py.xlsx"
    result = subprocess.run(
        ["py", "main.py", "plantilla", "--output", str(destino)],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert destino.is_file()
