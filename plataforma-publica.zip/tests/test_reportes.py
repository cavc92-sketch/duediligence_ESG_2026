from pathlib import Path
from descarbonizacion.reportes import crear_graficos
from tests.test_modelo import preparar_serie, pd
from descarbonizacion.analisis import analizar_impacto
from descarbonizacion.ejercicios import evaluar_capex
from descarbonizacion.expediente import crear_expediente, crear_excel_resultados
from descarbonizacion.plantilla import crear_plantilla


def test_crear_graficos_genera_lamina_y_cuatro_graficos(tmp_path: Path):
    fechas = pd.date_range("2022-01-01", periods=30, freq="MS")
    detalle, resumen = analizar_impacto(preparar_serie(pd.DataFrame({"fecha": fechas, "consumo_kwh": [1000 + i if i < 18 else 800 + i for i in range(30)]})), pd.Timestamp("2023-07-01"), 0.2)
    paths = crear_graficos(detalle, resumen, {"nombre_activo": "Activo Ejemplo", "fecha_intervencion": "2023-07-01", "tipo_intervencion": "LED"}, tmp_path)
    assert len(paths) == 5
    assert paths["lamina"].is_file()


def test_evaluar_capex_clasifica_beneficio_no_cuantificado_como_hipotesis():
    capex = pd.DataFrame([{
        "id_iniciativa": "SOL-1",
        "capex_cop": 1000,
        "ahorro_esperado_cop_anio": None,
        "ahorro_observado_cop_anio": None,
    }])
    result = evaluar_capex(capex)
    assert result.loc[0, "estado_beneficio"] == "Hipótesis de inversión"


def test_crear_expediente_conserva_hash_y_excepciones(tmp_path: Path):
    entrada = tmp_path / "entrada.xlsx"
    entrada.write_bytes(b"evidencia de prueba")
    salida = crear_expediente(entrada, tmp_path / "resultado", {"modo": "operativo"}, [{"tipo": "duplicado"}])
    assert len(salida["hash_entrada"]) == 64
    assert salida["excepciones"] == [{"tipo": "duplicado"}]
    assert (tmp_path / "resultado" / "manifiesto_auditoria.json").is_file()


def test_crear_excel_resultados_escribe_resumen_desde_fila_cinco(tmp_path: Path):
    origen = crear_plantilla(tmp_path / "entrada.xlsx")
    destino = crear_excel_resultados(origen, tmp_path / "reporte.xlsx", {"nombre_activo": "Bodega"}, {"modo": "operativo", "consumo_kwh_total": 100}, [], pd.DataFrame())
    reporte = pd.read_excel(destino, sheet_name="08_Reporte_por_activo", header=None)
    assert reporte.iloc[4, 0] == "ID activo"


def test_crear_excel_resultados_migra_consumos_de_formato_antiguo(tmp_path: Path):
    origen = tmp_path / "legacy.xlsx"
    with pd.ExcelWriter(origen) as writer:
        pd.DataFrame({"Campo": ["nombre_activo", "factor_emision_kgco2e_kwh"], "Valor": ["Bodega", 0.2]}).to_excel(writer, sheet_name="Activo", index=False)
        pd.DataFrame({"fecha": [pd.Timestamp("2024-01-01")], "consumo_kwh": [100.0]}).to_excel(writer, sheet_name="Consumo_mensual", index=False)
    destino = crear_excel_resultados(origen, tmp_path / "reporte.xlsx", {"nombre_activo": "Bodega"}, {"modo": "operativo"}, [], pd.DataFrame())
    consumos = pd.read_excel(destino, sheet_name="03_Consumos", header=3)
    assert consumos.loc[0, "recurso"] == "Electricidad"
    assert consumos.loc[0, "valor"] == 100.0
    assert "99_Origen_Consumos" in pd.ExcelFile(destino).sheet_names
