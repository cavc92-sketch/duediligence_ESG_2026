"""Punto de entrada único para la plataforma de sostenibilidad por activo."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def _usar_entorno_virtual_del_proyecto() -> None:
    """Permite usar `py main.py` sin perder las dependencias del modelo."""
    raiz = Path(__file__).resolve().parent
    entorno = raiz / ".venv" / "Scripts" / "python.exe"
    if entorno.is_file() and Path(sys.executable).resolve() != entorno.resolve():
        resultado = subprocess.run([str(entorno), str(Path(__file__).resolve()), *sys.argv[1:]], cwd=raiz)
        raise SystemExit(resultado.returncode)


_usar_entorno_virtual_del_proyecto()

from descarbonizacion.carga import cargar_activo
from descarbonizacion.ejercicios import evaluar_capex, ejecutar_due_diligence, ejecutar_operativo
from descarbonizacion.expediente import crear_excel_resultados, crear_expediente, crear_informe_markdown
from descarbonizacion.plantilla import crear_plantilla
from descarbonizacion.reportes import crear_graficos


def _nombre_seguro(valor: object) -> str:
    texto = re.sub(r"[^A-Za-z0-9_-]+", "_", str(valor or "activo").strip())
    return texto.strip("_") or "activo"


def _salida_por_defecto(meta: dict) -> Path:
    fecha = datetime.now().strftime("%Y%m%d_%H%M%S")
    return Path("output") / f"{_nombre_seguro(meta.get('id_activo') or meta.get('nombre_activo'))}_{fecha}"


def analizar_archivo(entrada: Path, ejercicio: str = "completo", salida: Path | None = None) -> Path:
    """Ejecuta un ejercicio, mantiene la entrada intacta y devuelve la carpeta de salida."""
    entrada = Path(entrada)
    meta, consumos, factores, capex, riesgos = cargar_activo(entrada)
    salida = Path(salida) if salida else _salida_por_defecto(meta)
    salida.mkdir(parents=True, exist_ok=True)
    detalle, operativo, excepciones = ejecutar_operativo(meta, consumos, factores)
    due = ejecutar_due_diligence(riesgos)
    capex_resultado = evaluar_capex(capex)
    if ejercicio == "due-diligence":
        resumen = {**due, "modo": "due_diligence"}
    elif ejercicio == "capex":
        resumen = {"modo": "capex", "iniciativas_capex": int(len(capex_resultado)), "limitacion": "Los beneficios no observados se tratan como hipótesis de inversión."}
    elif ejercicio == "operativo":
        resumen = operativo
    else:
        resumen = {**operativo, "modo": "completo", "due_diligence": due, "iniciativas_capex": int(len(capex_resultado))}
    if not detalle.empty:
        detalle.to_csv(salida / "serie_preparada_auditable.csv", index=False, encoding="utf-8-sig")
    capex_resultado.to_csv(salida / "capex_evaluado.csv", index=False, encoding="utf-8-sig")
    (salida / "resumen.json").write_text(json.dumps(resumen, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    (salida / "excepciones_calidad.json").write_text(json.dumps(excepciones, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    if operativo.get("modo") == "impacto_pre_post" and not detalle.empty:
        meta_grafico = {"nombre_activo": meta.get("nombre_activo", meta.get("id_activo", "Activo")), "fecha_intervencion": meta.get("fecha_intervencion"), "tipo_intervencion": meta.get("tipo_intervencion", "Intervención")}
        crear_graficos(detalle, operativo, meta_grafico, salida)
    manifiesto = crear_expediente(entrada, salida, resumen, excepciones, {"ejercicio": ejercicio, "id_activo": meta.get("id_activo")})
    crear_informe_markdown(salida, meta, resumen, due, capex_resultado, excepciones, manifiesto)
    crear_excel_resultados(entrada, salida / "reporte_por_activo.xlsx", meta, resumen, excepciones, capex_resultado)
    return salida


def _menu() -> int:
    while True:
        print("\nPLATAFORMA DE SOSTENIBILIDAD POR ACTIVO")
        print("1. Crear plantilla Excel por activo")
        print("2. Analizar un archivo Excel diligenciado")
        print("3. Ver ayuda")
        print("0. Salir")
        opcion = input("Seleccione una opción: ").strip()
        if opcion == "1":
            destino = Path(input("Ruta para la plantilla [datos/plantilla_activo.xlsx]: ").strip() or "datos/plantilla_activo.xlsx")
            print(f"Plantilla creada en: {crear_plantilla(destino)}")
        elif opcion == "2":
            entrada = Path(input("Ruta del Excel: ").strip().strip('"'))
            ejercicio = input("Ejercicio [completo/operativo/due-diligence/capex] (completo): ").strip() or "completo"
            try:
                print(f"Resultados creados en: {analizar_archivo(entrada, ejercicio)}")
            except Exception as error:
                print(f"No fue posible analizar el archivo: {error}")
        elif opcion == "3":
            print("Diligencie primero el Excel. La plataforma no inventa datos: declara vacíos, excepciones y limitaciones.")
        elif opcion == "0":
            return 0
        else:
            print("Opción no válida.")


def main(argv: list[str] | None = None) -> int:
    argumentos = list(sys.argv[1:] if argv is None else argv)
    if not argumentos:
        return _menu()
    parser = argparse.ArgumentParser(description="Plataforma de sostenibilidad por activo.")
    sub = parser.add_subparsers(dest="comando", required=True)
    plantilla = sub.add_parser("plantilla", help="Crea el Excel guiado por activo.")
    plantilla.add_argument("--output", required=True, type=Path)
    analizar = sub.add_parser("analizar", help="Procesa un Excel sin modificarlo.")
    analizar.add_argument("--input", required=True, type=Path)
    analizar.add_argument("--output", type=Path)
    analizar.add_argument("--ejercicio", choices=["completo", "operativo", "due-diligence", "capex"], default="completo")
    args = parser.parse_args(argumentos)
    if args.comando == "plantilla":
        print(f"Plantilla creada en: {crear_plantilla(args.output)}")
    else:
        print(f"Resultados creados en: {analizar_archivo(args.input, args.ejercicio, args.output)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
