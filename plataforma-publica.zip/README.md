# Plataforma de sostenibilidad por activo — prototipo experimental

Herramienta local en Python y Excel para explorar información mensual de activos inmobiliarios en Colombia. Esta versión se comparte para recibir comentarios y pruebas con **datos ficticios**.

**Estado: prototipo de investigación; no está validado para informes públicos, decisiones de inversión, inventarios de emisiones ni auditoría.** Los resultados requieren revisión profesional. No representa cumplimiento de IFRS S2, ISSA 5000 ni ISAE 3000.

## Requisitos

- Windows y Python 3.14 instalados desde [python.org](https://www.python.org/downloads/). Esta copia se ha probado con Python 3.14; otras versiones no se han verificado.
- Excel u otro programa compatible con archivos `.xlsx`.
- Conexión a internet para instalar las dependencias. El análisis se ejecuta localmente.

## Instalación desde GitHub

1. Descargue el repositorio con **Code → Download ZIP**, descomprímalo y abra la carpeta.
2. En la barra de dirección del Explorador escriba `cmd` y presione Enter.
3. Copie y ejecute cada línea por separado:

```cmd
py -3.14 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe main.py
```

En el menú seleccione **1** para crear una plantilla. Cuando pregunte la ruta, presione **Enter** para aceptar `datos/plantilla_activo.xlsx`. Abra ese archivo, complete únicamente datos ficticios, guárdelo y ciérrelo. Vuelva al menú y seleccione **2**; introduzca `datos\plantilla_activo.xlsx` y elija `completo` o presione Enter. Los resultados se guardan en `output`.

## Limitaciones conocidas

- Los controles de calidad y factores de emisión requieren revisión independiente: se puede seleccionar un factor sin validar su vigencia, unidad o fuente.
- La falta de datos de agua puede aparecer como cero; un factor faltante puede generar emisiones evitadas de cero. No interprete estos resultados como datos reales.
- Los datos imputados pueden participar en estimaciones y análisis PRE/POST; los duplicados excluidos pueden afectar la serie. La comparación no demuestra causalidad.
- El módulo CAPEX es preliminar: un ahorro registrado puede clasificarse como observado sin validación documental. No calcula un caso financiero completo para proyectos solares.
- El expediente contiene un hash del archivo de entrada; esto no garantiza integridad de todo el proceso ni constituye aseguramiento independiente.
- La herramienta no incluye IA, integración directa con SharePoint ni evaluación completa de IFRS S2. No se han verificado todos los casos de uso.

No cargue facturas, datos personales, archivos confidenciales ni claves en GitHub. Si una clave real se publicó alguna vez, elimínela y revóquela con su proveedor: borrar el archivo no elimina el historial público.

## Pruebas

```cmd
.venv\Scripts\python.exe -m pytest -q
```

Los archivos de `datos/` y `output/` se excluyen por defecto mediante `.gitignore`.

## Licencia

No se ha seleccionado licencia de código abierto. Todos los derechos quedan reservados hasta que la persona titular elija y agregue una licencia.
