from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from .config import PALETTE


def _save(fig, path):
    fig.savefig(path, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def crear_graficos(detalle, resumen, metadatos, directorio: Path):
    directorio = Path(directorio); directorio.mkdir(parents=True, exist_ok=True)
    pre, post = detalle.periodo.eq("PRE"), detalle.periodo.eq("POST")
    paths = {}
    fig, ax = plt.subplots(figsize=(12, 5)); ax.plot(detalle.loc[pre,"fecha"], detalle.loc[pre,"consumo_kwh_analisis"], color=PALETTE["navy"], label="Histórico (antes)"); ax.plot(detalle.fecha, detalle.contrafactual_kwh, "--", color=PALETTE["blue_gray"], label="Contrafactual"); ax.plot(detalle.loc[post,"fecha"], detalle.loc[post,"consumo_kwh_analisis"], color=PALETTE["slate"], label="Observado (después)"); ax.set(title="Consumo mensual (kWh)", ylabel="kWh"); ax.legend(); ax.grid(axis="y", alpha=.25); paths["serie_historica"] = directorio/"serie_historica.png"; _save(fig, paths["serie_historica"])
    fig, ax = plt.subplots(figsize=(12, 5)); ax.plot(detalle.loc[post,"fecha"], detalle.loc[post,"contrafactual_kwh"], "--", color=PALETTE["blue_gray"], label="Línea base"); ax.plot(detalle.loc[post,"fecha"], detalle.loc[post,"consumo_kwh_analisis"], color=PALETTE["terracotta"], label="Realidad"); ax.set(title="Línea base vs. realidad", ylabel="kWh"); ax.legend(); ax.grid(axis="y", alpha=.25); paths["linea_base"] = directorio/"linea_base_vs_realidad.png"; _save(fig, paths["linea_base"])
    for column, label, key in [("kwh_evitados", "Impacto acumulado (kWh evitados)", "kwh_acumulado"), ("tco2e_evitadas", "CO₂e evitado acumulado (tCO₂e)", "co2_acumulado")]:
        fig, ax = plt.subplots(figsize=(12, 5)); data=detalle.loc[post]; ax.fill_between(data.fecha, data[column].cumsum(), color=PALETTE["light_gray"]); ax.plot(data.fecha, data[column].cumsum(), color=PALETTE["slate"], linewidth=2); ax.set(title=label); ax.grid(axis="y", alpha=.25); paths[key] = directorio/f"{key}.png"; _save(fig, paths[key])
    fig = plt.figure(figsize=(16, 9), facecolor="white"); gs=GridSpec(3, 4, figure=fig, height_ratios=[.8,2,1.4]); fig.text(.05,.94,f"Impacto de Descarbonización — {metadatos['nombre_activo']}",size=22,weight="bold",color=PALETTE["navy"]); fig.text(.94,.945,"DATOS DEL ACTIVO",ha="right",color=PALETTE["blue_gray"])
    cards=[("Reducción",f"{resumen['reduccion_pct']:.1%}"),("kWh evitados",f"{resumen['kwh_evitados']:,.0f}"),("tCO₂e evitadas",f"{resumen['tco2e_evitadas']:,.1f}"),("Evidencia",f"p = {resumen['p_itsa']:.3f}")]
    for i,(label,value) in enumerate(cards): ax=fig.add_subplot(gs[0,i]); ax.set_facecolor(PALETTE["navy"] if i==0 else PALETTE["slate"]); ax.text(.5,.62,value,ha="center",color="white",size=19,weight="bold"); ax.text(.5,.27,label,ha="center",color="white",size=10); ax.set_xticks([]);ax.set_yticks([])
    ax=fig.add_subplot(gs[1,:3]); ax.plot(detalle.loc[pre,"fecha"],detalle.loc[pre,"consumo_kwh_analisis"],color=PALETTE["navy"],label="Antes"); ax.plot(detalle.loc[post,"fecha"],detalle.loc[post,"contrafactual_kwh"],"--",color=PALETTE["blue_gray"],label="Sin intervención"); ax.plot(detalle.loc[post,"fecha"],detalle.loc[post,"consumo_kwh_analisis"],color=PALETTE["terracotta"],label="Después"); ax.set_title("Consumo mensual (kWh)",loc="left",color=PALETTE["navy"],weight="bold");ax.legend(ncol=3);ax.grid(axis="y",alpha=.2)
    ax=fig.add_subplot(gs[1,3]); ax.bar(["Antes","Después"],[resumen["consumo_pre_promedio"],resumen["consumo_post_promedio"]],color=[PALETTE["navy"],PALETTE["terracotta"]]);ax.set_title("Promedio kWh",color=PALETTE["navy"],weight="bold");ax.grid(axis="y",alpha=.2)
    ax=fig.add_subplot(gs[2,:]); data=detalle.loc[post]; ax.fill_between(data.fecha,data.kwh_evitados.cumsum(),color=PALETTE["light_gray"]);ax.plot(data.fecha,data.kwh_evitados.cumsum(),color=PALETTE["slate"],linewidth=2);ax.set_title("Impacto acumulado (kWh evitados)",loc="left",color=PALETTE["navy"],weight="bold");ax.grid(axis="y",alpha=.2); fig.text(.05,.02,resumen["conclusion"]+f"  ·  Meses imputados: {resumen['imputaciones']}",color=PALETTE["charcoal"],size=11)
    paths["lamina"] = directorio/"lamina_ejecutiva_16x9.png"; _save(fig, paths["lamina"]); return paths
