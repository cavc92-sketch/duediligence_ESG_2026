PALETTE = {
    "charcoal": "#202020", "navy": "#0B264F", "slate": "#2F4252",
    "blue_gray": "#7C878E", "light_gray": "#CBD1D5", "terracotta": "#A9431E",
    "white": "#FFFFFF", "positive": "#2F4252",
}
MIN_PRE_MONTHS = 12
MIN_POST_MONTHS = 6
ALGORITHM_VERSION = "2.0.0"
