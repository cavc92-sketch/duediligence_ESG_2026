"""Creación de la plantilla única de sostenibilidad por activo."""

from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation


COLORES = {
    "azul": "0A1E42",
    "pizarra": "253746",
    "gris": "7C878E",
    "claro": "DEE3E6",
    "terracota": "A9431E",
    "entrada": "FFFDF2",
    "blanco": "FFFFFF",
}
BORDE = Border(*(Side(style="thin", color=COLORES["claro"]) for _ in range(4)))


def _titulo(ws, titulo: str, subtitulo: str, columnas: int) -> None:
    ws.sheet_view.showGridLines = False
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=columnas)
    ws.cell(1, 1, titulo)
    ws.cell(1, 1).fill = PatternFill("solid", fgColor=COLORES["azul"])
    ws.cell(1, 1).font = Font(color=COLORES["blanco"], bold=True, size=15)
    ws.cell(1, 1).alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 28
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=columnas)
    ws.cell(2, 1, subtitulo)
    ws.cell(2, 1).fill = PatternFill("solid", fgColor=COLORES["claro"])
    ws.cell(2, 1).font = Font(italic=True, color=COLORES["pizarra"])
    ws.cell(2, 1).alignment = Alignment(wrap_text=True, vertical="center")
    ws.row_dimensions[2].height = 34
    ws.freeze_panes = "A5"


def _encabezados(ws, titulos: list[str]) -> None:
    for columna, titulo in enumerate(titulos, start=1):
        celda = ws.cell(4, columna, titulo)
        celda.fill = PatternFill("solid", fgColor=COLORES["pizarra"])
        celda.font = Font(color=COLORES["blanco"], bold=True)
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        celda.border = BORDE
    ws.row_dimensions[4].height = 34


def _formatear_entradas(ws, desde: int, hasta: int, columnas: int) -> None:
    for fila in ws.iter_rows(min_row=desde, max_row=hasta, min_col=1, max_col=columnas):
        for celda in fila:
            celda.fill = PatternFill("solid", fgColor=COLORES["entrada"])
            celda.border = BORDE
            celda.alignment = Alignment(vertical="center", wrap_text=True)


def _validacion_lista(ws, rango: str, opciones: list[str]) -> None:
    validacion = DataValidation(type="list", formula1='"' + ",".join(opciones) + '"', allow_blank=True)
    ws.add_data_validation(validacion)
    validacion.add(rango)


def _anchos(ws, anchos: list[int]) -> None:
    for indice, ancho in enumerate(anchos, start=1):
        ws.column_dimensions[chr(64 + indice)].width = ancho


def crear_plantilla(destino: Path) -> Path:
    """Crea un Excel guiado por activo y devuelve su ruta."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    libro = Workbook()
    libro.remove(libro.active)

    solicitud = libro.create_sheet("00_Solicitud")
    _titulo(solicitud, "Solicitud de información — evaluación por activo", "Envíe esta hoja al solicitante. Los vacíos se declaran y no se inventan.", 8)
    _encabezados(solicitud, ["Prioridad", "Bloque", "Información solicitada", "Formato / periodo", "Evidencia aceptable", "Responsable", "Entregado", "Observaciones"])
    filas_solicitud = [
        ["Mínima", "Activo", "Nombre, ID interno, dirección, municipio y departamento", "Vigente", "Ficha técnica, contrato o administración", "Administrador", "No", ""],
        ["Mínima", "Límites", "Tipo, área, propiedad/operación y horario", "Periodo evaluado", "Ficha técnica", "Administrador", "No", ""],
        ["Mínima", "Energía", "Consumo mensual de electricidad", "Ideal 24–36 meses; mínimo 12", "Factura o medidor", "Operador", "No", ""],
        ["Mínima", "Agua", "Consumo mensual de agua", "Ideal 24–36 meses; mínimo 12", "Factura o medidor", "Operador", "No", ""],
        ["Mínima", "Calidad", "Vacíos, estimaciones y anomalías conocidos", "Todo el periodo", "Acta o correo del responsable", "Operador", "No", ""],
        ["Recomendada", "Huella", "Combustibles, refrigerantes, generación propia y factores", "Mensual / vigente", "Factura, bitácora y fuente", "Operador", "No", ""],
        ["Recomendada", "Operación", "Ocupación mensual y variable de actividad", "Mensual", "Reporte operativo", "Operador", "No", ""],
        ["Recomendada", "Riesgos", "Eventos, seguros, permisos e incidentes", "Últimos 3 años", "Pólizas, informes y permisos", "Asset manager", "No", ""],
        ["Recomendada", "CAPEX", "Medidas, presupuesto, aprobaciones y soporte", "Por iniciativa", "Caso de negocio y cotización", "Asset manager", "No", ""],
        ["Según tipo", "Data center", "Carga TI, PUE y respaldo eléctrico", "Mensual", "DCIM / informe técnico", "Operador", "No", "Sólo data center"],
    ]
    for fila in filas_solicitud:
        solicitud.append(fila)
    _formatear_entradas(solicitud, 5, 4 + len(filas_solicitud), 8)
    _validacion_lista(solicitud, "G5:G50", ["Sí", "Parcial", "No", "No aplica"])
    _anchos(solicitud, [14, 16, 38, 28, 38, 20, 13, 28])

    instrucciones = libro.create_sheet("01_Instrucciones")
    _titulo(instrucciones, "Plataforma de sostenibilidad por activo", "Excel para captura; Python para validación, cálculo y reporte.", 6)
    instrucciones.merge_cells("A4:F10")
    instrucciones["A4"] = (
        "1. Diligencie 02_Activo_y_límites.  2. Registre los consumos en 03_Consumos. "
        "3. Incluya los factores y la evidencia.  4. Registre riesgos e iniciativas CAPEX. "
        "5. Ejecute main.py para generar los resultados.\n\n"
        "Estados: Verificado = soporte y revisión completos; Estimado = método documentado; "
        "Incompleto = falta información material; No disponible = no existe base para calcular."
    )
    instrucciones["A4"].alignment = Alignment(wrap_text=True, vertical="top")
    instrucciones["A4"].fill = PatternFill("solid", fgColor="F4F6F7")
    instrucciones["A4"].border = BORDE
    _anchos(instrucciones, [24, 20, 20, 20, 20, 20])

    activo = libro.create_sheet("02_Activo_y_límites")
    _titulo(activo, "Activo y límites de reporte", "Diligencie los campos amarillos y mantenga el ID del activo en todos los soportes.", 3)
    _encabezados(activo, ["Campo", "Valor", "Evidencia / observación"])
    campos = [
        "id_activo", "nombre_activo", "tipo_activo", "direccion", "municipio", "departamento", "pais",
        "area_construida_m2", "area_arrendable_m2", "propiedad_operacion", "inicio_periodo", "fin_periodo",
        "responsable_activo", "revisor_interno", "limite_organizacional", "limite_operacional", "fecha_intervencion",
    ]
    for campo in campos:
        activo.append([campo, "Colombia" if campo == "pais" else "", ""])
    _formatear_entradas(activo, 5, 4 + len(campos), 3)
    _validacion_lista(activo, "B7:B7", ["Logístico / bodega", "Oficina", "Comercio", "Data center", "Vivienda estudiantil"])
    _validacion_lista(activo, "B14:B14", ["Propiedad", "Operación", "Mixto"])
    for fila in (15, 16, 21):
        activo.cell(fila, 2).number_format = "yyyy-mm-dd"
    _anchos(activo, [28, 32, 52])

    consumos = libro.create_sheet("03_Consumos")
    _titulo(consumos, "Consumos mensuales y evidencia", "Una fila por recurso, mes y medidor. No use cero para representar falta de información.", 12)
    _encabezados(consumos, ["fecha", "recurso", "medidor_cuenta", "valor", "unidad", "fuente", "id_factura_lectura", "ruta_evidencia", "responsable_carga", "fecha_carga", "estado_calidad", "observacion"])
    _formatear_entradas(consumos, 5, 204, 12)
    _validacion_lista(consumos, "B5:B204", ["Electricidad", "Agua", "Gas natural", "Diésel", "Gasolina", "Refrigerante", "Otro"])
    _validacion_lista(consumos, "E5:E204", ["kWh", "m³", "gal", "L", "kg", "Otro"])
    _validacion_lista(consumos, "F5:F204", ["Factura", "Medidor", "Proveedor", "Estimación documentada", "Otro"])
    _validacion_lista(consumos, "K5:K204", ["Verificado", "Estimado", "Incompleto", "No disponible"])
    for fila in range(5, 205):
        consumos.cell(fila, 1).number_format = "yyyy-mm-dd"
        consumos.cell(fila, 4).number_format = "#,##0.00"
        consumos.cell(fila, 10).number_format = "yyyy-mm-dd"
    _anchos(consumos, [13, 17, 18, 14, 12, 22, 20, 42, 20, 14, 16, 28])

    huella = libro.create_sheet("04_Huella")
    _titulo(huella, "Factores de emisión", "Registre la fuente y versión del factor usado; no se aceptan factores sin trazabilidad.", 10)
    _encabezados(huella, ["recurso", "alcance", "unidad_actividad", "factor_kgco2e_unidad", "fuente_oficial", "version_vigencia", "fecha_aprobacion", "aprobado_por", "estado_calidad", "observacion"])
    _formatear_entradas(huella, 5, 54, 10)
    _validacion_lista(huella, "B5:B54", ["Alcance 1", "Alcance 2", "Alcance 3"])
    _validacion_lista(huella, "I5:I54", ["Verificado", "Estimado", "Incompleto", "No disponible"])
    _anchos(huella, [18, 14, 18, 22, 38, 18, 16, 20, 16, 26])

    capex = libro.create_sheet("05_CAPEX_y_medidas")
    _titulo(capex, "CAPEX, medidas y flujo protegido", "Si no existe cuantificación confiable, el beneficio se reporta como hipótesis de inversión.", 15)
    _encabezados(capex, ["id_iniciativa", "medida", "estado", "riesgo_mitigado", "flujo_protegido", "anio_capex", "capex_cop", "vida_util_anios", "ahorro_esperado_cop_anio", "ahorro_observado_cop_anio", "tco2e_esperadas_anio", "ruta_evidencia", "responsable", "aprobacion", "observacion"])
    _formatear_entradas(capex, 5, 104, 15)
    _validacion_lista(capex, "C5:C104", ["Idea", "En evaluación", "Aprobada", "En ejecución", "Ejecutada", "Descartada"])
    _validacion_lista(capex, "E5:E104", ["Ahorro operativo", "Ingreso", "Continuidad operativa", "Costo de financiación", "Valor del activo", "Mitigación regulatoria"])
    _validacion_lista(capex, "N5:N104", ["Pendiente", "Aprobada", "Rechazada", "No aplica"])
    _anchos(capex, [15, 24, 16, 26, 23, 12, 16, 15, 21, 21, 23, 36, 20, 15, 26])

    riesgos = libro.create_sheet("06_Due_diligence")
    _titulo(riesgos, "Due diligence climática y de sostenibilidad", "Los riesgos sin evidencia se registran como pendientes de diligencia, no como ausencia de riesgo.", 13)
    _encabezados(riesgos, ["id_riesgo", "categoria", "riesgo_oportunidad", "horizonte", "probabilidad", "severidad", "impacto_financiero_cop", "ruta_evidencia", "brecha", "recomendacion", "capex_relacionado", "responsable", "estado"])
    _formatear_entradas(riesgos, 5, 104, 13)
    _validacion_lista(riesgos, "B5:B104", ["Físico agudo", "Físico crónico", "Transición", "Oportunidad"])
    _validacion_lista(riesgos, "D5:D104", ["Corto", "Mediano", "Largo"])
    _validacion_lista(riesgos, "M5:M104", ["Pendiente de diligencia", "Abierto", "Mitigado", "Aceptado"])
    _anchos(riesgos, [13, 17, 32, 12, 14, 14, 24, 36, 25, 30, 18, 20, 22])

    calidad = libro.create_sheet("07_Calidad_y_auditoría")
    _titulo(calidad, "Calidad y preparación para aseguramiento", "Se completa automáticamente al ejecutar el modelo. No convierte datos incompletos en datos verificados.", 7)
    _encabezados(calidad, ["indicador", "registros", "verificados", "estimados", "incompletos_no_disponibles", "cobertura_verificada", "accion_requerida"])
    for indicador in ("Consumos", "Factores de emisión", "CAPEX", "Riesgos"):
        calidad.append([indicador, "", "", "", "", "", ""])
    _anchos(calidad, [24, 14, 14, 14, 24, 22, 42])

    reporte = libro.create_sheet("08_Reporte_por_activo")
    _titulo(reporte, "Reporte por activo", "El motor añade resultados, limitaciones y referencias a evidencia para cada ejercicio ejecutado.", 6)
    _encabezados(reporte, ["Dato", "Valor"])
    for dato in ("ID activo", "Nombre", "Tipo", "Ejercicio", "Calidad de consumos", "Limitaciones"):
        reporte.append([dato, ""])
    _anchos(reporte, [32, 70, 18, 18, 18, 18])

    libro.save(destino)
    return destino
