import numpy as np
import pandas as pd


def preparar_serie(consumos: pd.DataFrame) -> pd.DataFrame:
    required = {"fecha", "consumo_kwh"}
    if not required.issubset(consumos.columns):
        raise ValueError("La hoja Consumo_mensual debe incluir fecha y consumo_kwh.")
    serie = consumos.loc[:, ["fecha", "consumo_kwh"]].copy()
    serie["fecha"] = pd.to_datetime(serie["fecha"]).dt.to_period("M").dt.to_timestamp()
    serie["consumo_kwh"] = pd.to_numeric(serie["consumo_kwh"], errors="coerce")
    if serie["fecha"].duplicated().any() or (serie["consumo_kwh"].dropna() < 0).any():
        raise ValueError("No se permiten fechas duplicadas ni consumos negativos.")
    serie = serie.set_index("fecha").asfreq("MS").reset_index()
    serie["consumo_kwh_original"] = serie["consumo_kwh"]
    serie["es_imputado"] = serie["consumo_kwh"].isna()
    if serie["consumo_kwh"].notna().sum() == 0:
        raise ValueError("Se requiere al menos un consumo observado.")
    same_month = serie.groupby(serie["fecha"].dt.month)["consumo_kwh"].transform("mean")
    general = serie["consumo_kwh"].mean()
    serie["consumo_kwh_analisis"] = serie["consumo_kwh"].fillna(same_month).fillna(general)
    serie["metodo_imputacion"] = np.where(~serie["es_imputado"], "observado", np.where(same_month.notna(), "media_mismo_mes", "media_general"))
    return serie
