"""Ejercicios por activo: operación, due diligence y CAPEX."""

from __future__ import annotations

from typing import Any
import numpy as np
import pandas as pd

from .analisis import analizar_impacto
from .preparacion import preparar_serie


ESTADOS_VERIFICADOS = {"Verificado"}


def _texto(valor: Any) -> str:
    return "" if pd.isna(valor) else str(valor).strip()


def validar_consumos(consumos: pd.DataFrame) -> list[dict[str, Any]]:
    """Devuelve excepciones trazables sin modificar la fuente."""
    requeridas = {"fecha", "recurso", "medidor_cuenta", "valor", "unidad", "estado_calidad"}
    faltantes = requeridas.difference(consumos.columns)
    if faltantes:
        return [{"tipo": "columnas_faltantes", "detalle": ", ".join(sorted(faltantes)), "filas": []}]
    datos = consumos.copy()
    datos["fecha"] = pd.to_datetime(datos["fecha"], errors="coerce").dt.to_period("M").dt.to_timestamp()
    datos["valor"] = pd.to_numeric(datos["valor"], errors="coerce")
    excepciones: list[dict[str, Any]] = []
    for nombre, mascara, detalle in (
        ("fecha_invalida", datos["fecha"].isna(), "La fecha no corresponde a un mes válido."),
        ("valor_invalido", datos["valor"].isna(), "El valor no es numérico."),
        ("valor_negativo", datos["valor"].lt(0), "No se permiten consumos negativos."),
        ("evidencia_ausente", datos.get("ruta_evidencia", pd.Series("", index=datos.index)).map(_texto).eq(""), "Falta ruta o enlace de evidencia."),
    ):
        filas = (datos.index[mascara] + 2).tolist()
        if filas:
            excepciones.append({"tipo": nombre, "detalle": detalle, "filas": filas})
    duplicados = datos.duplicated(["fecha", "recurso", "medidor_cuenta"], keep=False)
    filas = (datos.index[duplicados] + 2).tolist()
    if filas:
        excepciones.append({"tipo": "duplicado", "detalle": "Hay más de un registro para fecha, recurso y medidor.", "filas": filas})
    return excepciones


def _factor_electricidad(factores: pd.DataFrame) -> float | None:
    if factores.empty or "recurso" not in factores or "factor_kgco2e_unidad" not in factores:
        return None
    seleccion = factores.loc[factores["recurso"].map(_texto).str.casefold().eq("electricidad")].copy()
    if seleccion.empty:
        return None
    seleccion["factor_kgco2e_unidad"] = pd.to_numeric(seleccion["factor_kgco2e_unidad"], errors="coerce")
    factor = seleccion["factor_kgco2e_unidad"].dropna()
    return None if factor.empty else float(factor.iloc[0])


def _serie_electricidad(consumos: pd.DataFrame, excepciones: list[dict[str, Any]]) -> pd.DataFrame:
    datos = consumos.copy()
    datos["fecha"] = pd.to_datetime(datos["fecha"], errors="coerce").dt.to_period("M").dt.to_timestamp()
    datos["valor"] = pd.to_numeric(datos["valor"], errors="coerce")
    datos["recurso"] = datos["recurso"].map(_texto)
    datos["unidad"] = datos["unidad"].map(_texto)
    datos["medidor_cuenta"] = datos["medidor_cuenta"].map(_texto)
    electr = datos.loc[datos["recurso"].str.casefold().eq("electricidad") & datos["unidad"].str.casefold().eq("kwh")].copy()
    duplicados = electr.duplicated(["fecha", "recurso", "medidor_cuenta"], keep=False)
    valida = electr["fecha"].notna() & electr["valor"].notna() & electr["valor"].ge(0) & ~duplicados
    limpia = electr.loc[valida]
    return limpia.groupby("fecha", as_index=False)["valor"].sum().rename(columns={"valor": "consumo_kwh"})


def _agua_total(consumos: pd.DataFrame) -> float:
    datos = consumos.copy()
    if not {"recurso", "unidad", "valor"}.issubset(datos.columns):
        return 0.0
    datos["valor"] = pd.to_numeric(datos["valor"], errors="coerce")
    es_agua = datos["recurso"].map(_texto).str.casefold().eq("agua") & datos["unidad"].map(_texto).str.casefold().eq("m³")
    return float(datos.loc[es_agua & datos["valor"].ge(0), "valor"].sum())


def ejecutar_operativo(meta: dict, consumos: pd.DataFrame, factores: pd.DataFrame):
    """Ejecuta tendencia o PRE/POST con base en el Excel controlado."""
    excepciones = validar_consumos(consumos)
    serie_origen = _serie_electricidad(consumos, excepciones)
    factor = _factor_electricidad(factores)
    if serie_origen.empty:
        resumen = {
            "modo": "sin_consumo_electricidad", "consumo_kwh_total": 0.0, "agua_m3_total": _agua_total(consumos),
            "tco2e_total": None, "limitacion": "No hay consumos de electricidad válidos en kWh para analizar.",
        }
        return pd.DataFrame(), resumen, excepciones
    detalle = preparar_serie(serie_origen)
    detalle["tco2e_consumo"] = detalle["consumo_kwh_analisis"] * factor / 1000 if factor is not None else np.nan
    fecha_intervencion = meta.get("fecha_intervencion")
    fecha_intervencion = pd.to_datetime(fecha_intervencion, errors="coerce") if fecha_intervencion is not None else pd.NaT
    hay_muestra = False
    if pd.notna(fecha_intervencion):
        mes = fecha_intervencion.to_period("M").to_timestamp()
        hay_muestra = int(detalle["fecha"].lt(mes).sum()) >= 3 and int(detalle["fecha"].gt(mes).sum()) >= 3
    if hay_muestra:
        detalle, impacto = analizar_impacto(detalle, fecha_intervencion, factor or 0.0)
        impacto.update({"modo": "impacto_pre_post", "consumo_kwh_total": float(serie_origen["consumo_kwh"].sum()), "agua_m3_total": _agua_total(consumos), "tco2e_total": float(detalle["tco2e_consumo"].sum()) if factor is not None else None})
        return detalle, impacto, excepciones
    total = float(serie_origen["consumo_kwh"].sum())
    pendiente = float(detalle["consumo_kwh_analisis"].iloc[-1] - detalle["consumo_kwh_analisis"].iloc[0]) if len(detalle) > 1 else 0.0
    resumen = {
        "modo": "operativo_sin_intervencion", "consumo_kwh_total": total, "agua_m3_total": _agua_total(consumos),
        "tco2e_total": round(total * factor / 1000, 12) if factor is not None else None,
        "variacion_kwh_serie": pendiente, "meses_imputados": int(detalle["es_imputado"].sum()),
        "limitacion": "No se ejecutó inferencia causal: falta fecha de intervención o muestra PRE/POST suficiente.",
    }
    return detalle, resumen, excepciones


def ejecutar_due_diligence(riesgos: pd.DataFrame) -> dict[str, Any]:
    """Resume riesgos y brechas declaradas sin asumir que una brecha es ausencia de riesgo."""
    if riesgos.empty:
        return {"modo": "due_diligence", "riesgos_registrados": 0, "pendientes_diligencia": 0, "limitacion": "No hay riesgos registrados; se requiere diligencia."}
    estados = riesgos.get("estado", pd.Series("", index=riesgos.index)).map(_texto)
    evidencias = riesgos.get("ruta_evidencia", pd.Series("", index=riesgos.index)).map(_texto)
    return {
        "modo": "due_diligence", "riesgos_registrados": int(len(riesgos)),
        "pendientes_diligencia": int(estados.eq("Pendiente de diligencia").sum()),
        "sin_evidencia": int(evidencias.eq("").sum()),
        "limitacion": "Los riesgos sin evidencia se conservan como pendientes de diligencia.",
    }


def evaluar_capex(capex: pd.DataFrame) -> pd.DataFrame:
    """Clasifica beneficios de CAPEX sin transformar expectativas en beneficios realizados."""
    resultado = capex.copy()
    if resultado.empty:
        resultado["estado_beneficio"] = pd.Series(dtype="object")
        return resultado
    ahorro = pd.to_numeric(resultado.get("ahorro_esperado_cop_anio"), errors="coerce")
    observado = pd.to_numeric(resultado.get("ahorro_observado_cop_anio"), errors="coerce")
    inversion = pd.to_numeric(resultado.get("capex_cop"), errors="coerce")
    resultado["estado_beneficio"] = np.select(
        [observado.gt(0), ahorro.gt(0) | inversion.gt(0)],
        ["Beneficio observado", "Hipótesis de inversión"],
        default="Sin beneficio cuantificado",
    )
    return resultado
