import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy.stats import mannwhitneyu, shapiro, ttest_ind
from .config import MIN_POST_MONTHS, MIN_PRE_MONTHS


def analizar_impacto(serie: pd.DataFrame, fecha_intervencion: pd.Timestamp, factor_emision: float):
    if factor_emision < 0:
        raise ValueError("El factor de emisión debe ser no negativo.")
    model = serie.copy()
    intervention = pd.Timestamp(fecha_intervencion).to_period("M").to_timestamp()
    model["periodo"] = np.select([model.fecha < intervention, model.fecha > intervention], ["PRE", "POST"], default="INTERVENCION")
    model["tiempo"] = np.arange(len(model), dtype=float)
    post_start = model.index[model.periodo.eq("POST")].min()
    model["post"] = model.periodo.eq("POST").astype(int)
    model["tiempo_post"] = np.where(model.post.eq(1), model.tiempo - (post_start if pd.notna(post_start) else 0), 0.0)
    inferencia = int(model.periodo.eq("PRE").sum()) >= MIN_PRE_MONTHS and int(model.periodo.eq("POST").sum()) >= MIN_POST_MONTHS
    pre = model.loc[model.periodo.eq("PRE"), "consumo_kwh_analisis"]
    post = model.loc[model.periodo.eq("POST"), "consumo_kwh_analisis"]
    fit = smf.ols("consumo_kwh_analisis ~ tiempo + post + tiempo_post", data=model.loc[model.periodo.ne("INTERVENCION")]).fit(cov_type="HC3")
    model["contrafactual_kwh"] = fit.params["Intercept"] + fit.params["tiempo"] * model["tiempo"]
    model["kwh_evitados"] = np.where(model.periodo.eq("POST"), model.contrafactual_kwh - model.consumo_kwh_analisis, 0.0)
    model["tco2e_evitadas"] = model.kwh_evitados * factor_emision / 1000
    p_itsa = float(fit.pvalues.get("post", np.nan))
    normal = len(pre) >= 3 and len(post) >= 3 and shapiro(pre).pvalue >= 0.05 and shapiro(post).pvalue >= 0.05
    test_name = "t de Welch" if normal else "Mann-Whitney U"
    p_complementaria = float(ttest_ind(pre, post, equal_var=False).pvalue if normal else mannwhitneyu(pre, post, alternative="two-sided").pvalue)
    significant = inferencia and p_itsa < 0.05 and model.loc[model.periodo.eq("POST"), "kwh_evitados"].sum() > 0
    conclusion = "La disminución observada es estadísticamente significativa (p < 0.05)." if significant else ("No existe evidencia estadística suficiente para afirmar una reducción atribuible." if inferencia else "Muestra insuficiente para una conclusión estadística inferencial.")
    resumen = {"elegible_inferencia": inferencia, "p_itsa": p_itsa, "p_complementaria": p_complementaria, "prueba_complementaria": test_name, "conclusion": conclusion, "consumo_pre_promedio": float(pre.mean()), "consumo_post_promedio": float(post.mean()), "kwh_evitados": float(model.kwh_evitados.sum()), "tco2e_evitadas": float(model.tco2e_evitadas.sum()), "reduccion_pct": float((1 - post.mean() / pre.mean()) if pre.mean() else np.nan), "imputaciones": int(model.es_imputado.sum())}
    return model, resumen
