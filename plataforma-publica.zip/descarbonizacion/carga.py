"""Lectura y normalización del libro controlado por activo."""

from pathlib import Path
import pandas as pd


HOJAS_REQUERIDAS = {
    "02_Activo_y_límites", "03_Consumos", "04_Huella", "05_CAPEX_y_medidas", "06_Due_diligence"
}


def _filas_con_dato(datos: pd.DataFrame, columna: str) -> pd.DataFrame:
    return datos.loc[datos[columna].notna() & datos[columna].astype(str).str.strip().ne("")].copy()


def cargar_activo(path: Path):
    """Lee las tablas de entrada sin alterar el libro original."""
    path = Path(path)
    excel = pd.ExcelFile(path)
    if {"Activo", "Consumo_mensual"}.issubset(excel.sheet_names):
        activo_legacy = pd.read_excel(path, sheet_name="Activo")
        meta = {
            str(fila.Campo).strip(): fila.Valor
            for fila in activo_legacy.loc[activo_legacy["Campo"].notna()].itertuples(index=False)
        }
        consumo_legacy = pd.read_excel(path, sheet_name="Consumo_mensual")
        if not {"fecha", "consumo_kwh"}.issubset(consumo_legacy.columns):
            raise ValueError("La hoja Consumo_mensual debe incluir fecha y consumo_kwh.")
        consumos = pd.DataFrame({
            "fecha": consumo_legacy["fecha"], "recurso": "Electricidad", "medidor_cuenta": "Principal",
            "valor": consumo_legacy["consumo_kwh"], "unidad": "kWh", "fuente": "Migrado desde formato anterior",
            "id_factura_lectura": "", "ruta_evidencia": "", "responsable_carga": "", "fecha_carga": pd.NaT,
            "estado_calidad": "Incompleto", "observacion": "Compatibilidad con plantilla anterior",
        })
        factor = pd.to_numeric(pd.Series([meta.get("factor_emision_kgco2e_kwh")]), errors="coerce").iloc[0]
        factores = pd.DataFrame({
            "recurso": ["Electricidad"], "alcance": ["Alcance 2"], "unidad_actividad": ["kWh"],
            "factor_kgco2e_unidad": [factor], "fuente_oficial": ["Migrado desde formato anterior"],
            "version_vigencia": ["No declarada"], "estado_calidad": ["Incompleto"],
        })
        return meta, consumos, factores, pd.DataFrame(), pd.DataFrame()
    faltantes = HOJAS_REQUERIDAS.difference(excel.sheet_names)
    if faltantes:
        raise ValueError(f"El archivo no es una plantilla válida. Faltan hojas: {', '.join(sorted(faltantes))}.")
    activo = pd.read_excel(path, sheet_name="02_Activo_y_límites", header=3)
    if not {"Campo", "Valor"}.issubset(activo.columns):
        raise ValueError("La hoja 02_Activo_y_límites debe contener las columnas Campo y Valor.")
    meta = {
        str(fila.Campo).strip(): fila.Valor
        for fila in activo.loc[activo["Campo"].notna()].itertuples(index=False)
    }
    consumos = _filas_con_dato(pd.read_excel(path, sheet_name="03_Consumos", header=3), "fecha")
    factores = _filas_con_dato(pd.read_excel(path, sheet_name="04_Huella", header=3), "recurso")
    capex = _filas_con_dato(pd.read_excel(path, sheet_name="05_CAPEX_y_medidas", header=3), "id_iniciativa")
    riesgos = _filas_con_dato(pd.read_excel(path, sheet_name="06_Due_diligence", header=3), "id_riesgo")
    return meta, consumos, factores, capex, riesgos
