"""Modelo auditable de descarbonización para un activo."""
