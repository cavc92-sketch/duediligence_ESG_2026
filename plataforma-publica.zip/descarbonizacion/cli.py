"""Compatibilidad con el comando anterior `python -m descarbonizacion.cli`."""

import sys

from main import main as plataforma_main


def main() -> int:
    """Redirige el formato histórico al punto de entrada único."""
    return plataforma_main(["analizar", *sys.argv[1:]])


if __name__ == "__main__":
    raise SystemExit(main())
