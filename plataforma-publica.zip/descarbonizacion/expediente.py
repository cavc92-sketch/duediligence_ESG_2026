"""Expediente reproducible para preparación de aseguramiento."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

from .config import ALGORITHM_VERSION


def hash_archivo(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as archivo:
        for bloque in iter(lambda: archivo.read(1024 * 1024), b""):
            digest.update(bloque)
    return digest.hexdigest()


def crear_expediente(entrada: Path, salida: Path, resumen: dict[str, Any], excepciones: list[dict[str, Any]], parametros: dict[str, Any] | None = None) -> dict[str, Any]:
    """Escribe un manifiesto inmutable por ejecución y devuelve su contenido."""
    entrada, salida = Path(entrada), Path(salida)
    salida.mkdir(parents=True, exist_ok=True)
    manifiesto = {
        "archivo_entrada": str(entrada.resolve()),
        "hash_entrada": hash_archivo(entrada),
        "fecha_calculo_utc": datetime.now(timezone.utc).isoformat(),
        "algoritmo": ALGORITHM_VERSION,
        "parametros": parametros or {},
        "resumen": resumen,
        "excepciones": excepciones,
    }
    (salida / "manifiesto_auditoria.json").write_text(json.dumps(manifiesto, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return manifiesto


def crear_informe_markdown(salida: Path, meta: dict[str, Any], resumen: dict[str, Any], due_diligence: dict[str, Any], capex: pd.DataFrame, excepciones: list[dict[str, Any]], manifiesto: dict[str, Any]) -> Path:
    """Crea una lectura ejecutiva y declara las limitaciones de información."""
    activo = meta.get("nombre_activo") or meta.get("id_activo") or "Activo sin identificar"
    lineas = [
        f"# Informe por activo — {activo}", "", "## Alcance", f"- Ejercicio: {resumen.get('modo', 'No definido')}",
        f"- País: {meta.get('pais', 'Colombia')}", "", "## Resultados operativos",
    ]
    for clave in ("consumo_kwh_total", "agua_m3_total", "tco2e_total", "kwh_evitados", "tco2e_evitadas", "conclusion"):
        if clave in resumen:
            lineas.append(f"- {clave}: {resumen[clave]}")
    lineas += ["", "## Due diligence"]
    for clave, valor in due_diligence.items():
        lineas.append(f"- {clave}: {valor}")
    lineas += ["", "## CAPEX"]
    if capex.empty:
        lineas.append("- No hay iniciativas CAPEX registradas.")
    else:
        for fila in capex.itertuples(index=False):
            lineas.append(f"- {getattr(fila, 'id_iniciativa', 'Sin ID')}: {getattr(fila, 'estado_beneficio', 'Sin clasificar')}")
    lineas += ["", "## Calidad y limitaciones"]
    if not excepciones:
        lineas.append("- No se identificaron excepciones automáticas en los datos analizados.")
    else:
        for excepcion in excepciones:
            lineas.append(f"- {excepcion.get('tipo', 'excepción')}: {excepcion.get('detalle', 'Revisar filas indicadas.')}")
    lineas += ["", "Los datos estimados, incompletos o no disponibles no equivalen a datos verificados. Este informe prepara evidencia y no constituye una opinión de aseguramiento.", "", "## Trazabilidad", f"- Hash SHA-256 de entrada: `{manifiesto['hash_entrada']}`", f"- Algoritmo: {manifiesto['algoritmo']}"]
    path = Path(salida) / "informe_por_activo.md"
    path.write_text("\n".join(lineas), encoding="utf-8")
    return path


def crear_excel_resultados(origen: Path, destino: Path, meta: dict[str, Any], resumen: dict[str, Any], excepciones: list[dict[str, Any]], capex: pd.DataFrame) -> Path:
    """Copia el Excel de entrada y agrega resultados sin modificar su fuente."""
    origen, destino = Path(origen), Path(destino)
    libro = load_workbook(origen)
    es_formato_antiguo = {"Activo", "Consumo_mensual"}.issubset(libro.sheetnames)
    if not {"07_Calidad_y_auditoría", "08_Reporte_por_activo"}.issubset(libro.sheetnames):
        from .plantilla import crear_plantilla
        crear_plantilla(destino)
        libro = load_workbook(destino)
    if es_formato_antiguo:
        fuente = load_workbook(origen, data_only=False)
        activo_origen = fuente["Activo"]
        valores_activo = {fila[0]: fila[1] for fila in activo_origen.iter_rows(min_row=2, values_only=True) if fila[0]}
        activo_destino = libro["02_Activo_y_límites"]
        for fila in range(5, activo_destino.max_row + 1):
            campo = activo_destino.cell(fila, 1).value
            if campo in valores_activo:
                activo_destino.cell(fila, 2, valores_activo[campo])
        consumo_destino = libro["03_Consumos"]
        for fila_destino, fila_origen in enumerate(fuente["Consumo_mensual"].iter_rows(min_row=2, values_only=True), start=5):
            fecha, consumo_kwh = fila_origen[:2]
            if fecha is None:
                continue
            valores = [fecha, "Electricidad", "Principal", consumo_kwh, "kWh", "Migrado desde formato anterior", "", "", "", "", "Incompleto", "Compatibilidad con formato anterior"]
            for columna, valor in enumerate(valores, start=1):
                consumo_destino.cell(fila_destino, columna, valor)
        factor = valores_activo.get("factor_emision_kgco2e_kwh")
        if factor is not None:
            factor_destino = libro["04_Huella"]
            for columna, valor in enumerate(["Electricidad", "Alcance 2", "kWh", factor, "Migrado desde formato anterior", "No declarada", None, None, "Incompleto", "Compatibilidad con formato anterior"], start=1):
                factor_destino.cell(5, columna, valor)
        for nombre_origen, nombre_destino in (("Activo", "98_Origen_Activo"), ("Consumo_mensual", "99_Origen_Consumos")):
            if nombre_destino in libro.sheetnames:
                del libro[nombre_destino]
            copia = libro.create_sheet(nombre_destino)
            for fila in fuente[nombre_origen].iter_rows():
                for celda in fila:
                    copia.cell(celda.row, celda.column, celda.value)
    calidad = libro["07_Calidad_y_auditoría"]
    for fila in calidad.iter_rows(min_row=5, max_row=20, min_col=1, max_col=7):
        for celda in fila:
            celda.value = None
    filas = [
        ["Excepciones", len(excepciones), None, None, len(excepciones), None, "Revisar informe y filas señaladas" if excepciones else "Sin excepciones automáticas"],
        ["Modo de análisis", resumen.get("modo"), None, None, None, None, resumen.get("limitacion", "")],
    ]
    for numero_fila, fila in enumerate(filas, start=5):
        for columna, valor in enumerate(fila, start=1):
            calidad.cell(numero_fila, columna, valor)
    reporte = libro["08_Reporte_por_activo"]
    for fila in reporte.iter_rows(min_row=5, max_row=40, min_col=1, max_col=2):
        for celda in fila:
            celda.value = None
    base = [
        ["ID activo", meta.get("id_activo", "")], ["Nombre", meta.get("nombre_activo", "")], ["Tipo", meta.get("tipo_activo", "")],
        ["Ejercicio", resumen.get("modo", "")], ["Consumo kWh", resumen.get("consumo_kwh_total", "")],
        ["Agua m³", resumen.get("agua_m3_total", "")], ["Huella tCO2e", resumen.get("tco2e_total", "")],
        ["Limitaciones", resumen.get("limitacion", "")], ["Excepciones", len(excepciones)], ["Iniciativas CAPEX", len(capex)],
    ]
    for numero_fila, fila in enumerate(base, start=5):
        for columna, valor in enumerate(fila, start=1):
            reporte.cell(numero_fila, columna, valor)
    for ws in (calidad, reporte):
        ws["A4"].fill = PatternFill("solid", fgColor="253746")
        ws["A4"].font = Font(color="FFFFFF", bold=True)
    destino.parent.mkdir(parents=True, exist_ok=True)
    libro.save(destino)
    return destino
